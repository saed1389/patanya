<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SpecialCategoryModel extends Model
{
    use HasFactory;
    public $table = "specialCategory";
}
